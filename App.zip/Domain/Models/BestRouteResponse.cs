﻿namespace Domain.Models
{
    public class BestRouteResponse
    {
        public string Route { get; set; } = string.Empty;
        public decimal TotalCost { get; set; }
    }
}
